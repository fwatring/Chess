public abstract class ChessPiece
{
    protected int rowNum;
    protected int columnNum;
    protected int pieceColor;

    protected ChessPiece(int rowNum, int columnNum, int pieceColor)
    {
        this.rowNum = rowNum;
        this.columnNum = columnNum;
        this.pieceColor = pieceColor;
    }

    protected ChessPiece(int rowNum, int columnNum)
    {
        this.rowNum = rowNum;
        this.columnNum = columnNum;
	}

	public void move(int newRow, int newColumn)
    {
        this.rowNum = newRow;
        this.columnNum = newColumn;
    }

    public int getColor()
    {
        return pieceColor;
    }

    abstract char getLabel();

    abstract boolean isLegalMove(int destRow, int destCol, Board theBoard);

    abstract void generateLegalMoves(char[][] boardData, Board theBoard);
    


}