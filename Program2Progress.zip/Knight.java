public class Knight extends ChessPiece {

        /**
     * Constructor
     * 
     * @param rowNum     The row number where the piece is located
     * @param columnNum  The column number where the piece is located
     * @param pieceColor The color of this king
     */
    public Knight(int rowNum, int columnNum, int pieceColor)
    {
        super(rowNum, columnNum, pieceColor);
    }

    @Override
    public char getLabel()
    {
        return Board.WHITE_KNIGHT_LABEL;
    }

    @Override
    public boolean isLegalMove(int destRow, int destCol, Board theBoard)
    {
        int rowDiff = Math.abs(destRow - rowNum);
        int columnDiff = Math.abs(destCol - columnNum);
        int squareType = theBoard.getSquareInfo(destRow, destCol);

        boolean isLegal = (rowDiff <= 6 && columnDiff <= 6 || rowDiff <= 7 && columnDiff <= 7)
                && squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD;
        return isLegal;
    }

    @Override
    public void generateLegalMoves(char[][] boardData, Board theBoard)
    {
        char label = Board.WHITE_KNIGHT_LABEL;
        boardData[rowNum][columnNum] = label;
        int[] rowMoves = {-1, -2, -2, -1, 1, 2, 2, 1};
        int[] columnMoves = {2, 1, -1, -2, -2, -1, 1, 2};
       
        for(int counter1 = 0; counter1 < 8; counter1++)
        {
            for(int counter2 = 0; counter2 < 8 ; counter2++)
            {
                int squareType = theBoard.getSquareInfo(counter1, counter2);
                if (squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                {
                    int i = rowNum + rowMoves[counter1];
                    int j = columnNum + columnMoves[counter2];
                    if(i < 8 && j < 8)
                    {
                    boardData[i][j] = label;
                    }
                }
            }
        }
    }
            
   
    

}

