public class Rook extends ChessPiece {
        /**
     * Constructor
     * 
     * @param rowNum     The row number where the piece is located
     * @param columnNum  The column number where the piece is located
     * @param pieceColor The color of this king
     */
    public Rook(int rowNum, int columnNum, int pieceColor)
    {
        super(rowNum, columnNum, pieceColor);
    }

    @Override
    public char getLabel()
    {
        return Board.WHITE_ROOK_LABEL;
    }

    @Override
    public boolean isLegalMove(int destRow, int destCol, Board theBoard)
    {
        int rowDiff = Math.abs(destRow - rowNum);
        int columnDiff = Math.abs(destCol - columnNum);
        int squareType = theBoard.getSquareInfo(destRow, destCol);
        boolean isLegal = false;
        
        if(destCol > columnNum)
        {
            for(int j = columnNum + 1; j < destCol; j++)
            {
                int currSquare = theBoard.getSquareInfo(rowNum, j);
                if(theBoard.EMPTY_LABEL == currSquare  && squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                {
                    isLegal = true;
                }
            }
        }

        if(destCol < columnNum)
        {
            for(int j = columnNum - 1; j > destCol; j--)
            {
                int currSquare = theBoard.getSquareInfo(rowNum, j);
                if(theBoard.EMPTY_LABEL == currSquare  && squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                {
                    isLegal = true;
                }
            }
        }
        if(destRow > rowNum)
        {
            for(int i = columnNum + 1; i < destCol; i++)
            {
                int currSquare = theBoard.getSquareInfo(i, columnNum);
                if(theBoard.EMPTY_LABEL == currSquare  && squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                {
                    isLegal = true;
                }
            }
        }
        if(destRow < rowNum)
        {
            for(int i = columnNum - 1; i > destCol; i--)
            {
                int currSquare = theBoard.getSquareInfo(i, columnNum);
                if(theBoard.EMPTY_LABEL == currSquare  && squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                {
                    isLegal = true;
                }
            }
        }
            
        return isLegal;
    }

    @Override
    public void generateLegalMoves(char[][] boardData, Board theBoard)
    {
        
        char label = Board.WHITE_ROOK_LABEL;
        boardData[rowNum][columnNum] = label;
        
        //Generates Downwards
        
        for (int i = rowNum + 8; i >= rowNum; i--)
        {
            for (int j = columnNum; j <= columnNum; j++)
            {
               
                int squareType = theBoard.getSquareInfo(i, j);
                if(theBoard.EMPTY_LABEL == squareType)
                {
                    if (squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                    {
                    boardData[i][j] = label;
                    }
                }
            }
        }
        //Generates Upwards
        for (int i = rowNum - 8; i <= rowNum; i++)
        {
            for (int j = columnNum; j <= columnNum; j++)
            {
                int squareType = theBoard.getSquareInfo(i, j);
                if(theBoard.EMPTY_LABEL != squareType)
                {
                    if (squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                    boardData[i][j] = label;
                }
            }
        }
        
        //Generates Right
        for (int i = rowNum; i <= rowNum; i++)
        {
            for (int j = columnNum + 8; j >= columnNum; j--)
            {
                int squareType = theBoard.getSquareInfo(i, j);
                if(theBoard.EMPTY_LABEL != squareType)
                {
                    if (squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                    boardData[i][j] = label;
                }
            }
        }
        //Generates Left
        for (int i = rowNum; i <= rowNum; i++)
        {
            for (int j = columnNum - 8; j <= columnNum; j++)
            {
                int squareType = theBoard.getSquareInfo(i, j);
                if(theBoard.EMPTY_LABEL == squareType)
                {
                    if (squareType != this.pieceColor && squareType != Board.OFF_THE_BOARD)
                    boardData[i][j] = label;
                }
            }

        }
    }
}


